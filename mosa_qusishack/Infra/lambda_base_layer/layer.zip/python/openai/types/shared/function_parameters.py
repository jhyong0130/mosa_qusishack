# File generated from our OpenAPI spec by Stainless.

from typing import Dict

__all__ = ["FunctionParameters"]

FunctionParameters = Dict[str, object]
